#!/usr/bin/env python3
"""校验四张 PNG，输出内嵌图片的离线骑行网页。依赖 Pillow。"""
import argparse
import base64
import hashlib
import html
import json
import math
from pathlib import Path

from PIL import Image

from scene_contract import load_profile, validate_package


def load_png(path, transparent=False):
    with Image.open(path) as source:
        if source.format != "PNG":
            raise ValueError(f"需要 PNG：{path}")
        im = source.convert("RGBA")
    alpha = im.getchannel("A")
    histogram = alpha.histogram()
    report = {"size": list(im.size), "bbox": alpha.getbbox()}
    if transparent:
        fraction = histogram[0] / (im.width * im.height)
        if alpha.getextrema()[1] == 0 or fraction < 0.05:
            raise ValueError(f"人物图为空或缺少足够的真正透明区域：{path}")
        corners = [(0, 0), (im.width-1, 0), (0, im.height-1), (im.width-1, im.height-1)]
        if any(alpha.getpixel(point) != 0 for point in corners):
            raise ValueError(f"人物图四角应透明，请检查是否残留底色或被裁切：{path}")
        report["transparent_fraction"] = round(fraction, 4)
    elif alpha.getextrema() != (255, 255):
        raise ValueError("背景需要完全不透明")
    return im, report


def build(args):
    if not all(math.isfinite(v) for v in [args.track_y, args.ground_y, args.rider_width,
                                         args.cycle_ms, args.travel_seconds]):
        raise ValueError("参数必须是有限数字")
    if not (0 < args.track_y <= 1 and 0 < args.ground_y <= 1 and 0.05 <= args.rider_width <= 0.8):
        raise ValueError("track-y、ground-y 应在 (0,1]，rider-width 在 [0.05,0.8]")
    if args.cycle_ms < 150 or args.travel_seconds < 2:
        raise ValueError("cycle-ms 至少150，travel-seconds 至少2")
    output = args.output.resolve()
    if output.exists() and (not output.is_dir() or any(output.iterdir())):
        raise ValueError(f"输出目录须为新的或空目录：{output}")
    paths = [args.background, *args.frames]
    images, reports = [], []
    for index, path in enumerate(paths):
        im, report = load_png(path, transparent=index > 0)
        images.append(im)
        reports.append(report)
    if len({im.size for im in images[1:]}) != 1:
        raise ValueError("三帧画布尺寸不一致；先按车轮位置对齐并统一透明画布")
    if len({hashlib.sha256(im.tobytes()).digest() for im in images[1:]}) != 3:
        raise ValueError("人物帧存在完全相同的图像；需要三张不同的踏板姿态")
    profile, profile_hash = load_profile()
    geometry = None
    if not args.allow_legacy_layout:
        if args.geometry is None:
            raise ValueError("系列作品需要--geometry指向标准化输出的layout.json；先运行standardize_assets.py")
        geometry = json.loads(args.geometry.read_text(encoding="utf-8"))
        validate_package(images, geometry, profile, profile_hash)
        required = [profile["trackY"]/profile["backgroundSize"][1],
                    profile["riderGroundY"]/profile["frameSize"][1],
                    profile["riderDisplaySize"][0]/profile["backgroundSize"][0],
                    profile["cycleMs"], profile["travelSeconds"]]
        if any(not math.isclose(actual, expected, abs_tol=1e-9)
               for actual, expected in zip([args.track_y, args.ground_y, args.rider_width,
                                            args.cycle_ms, args.travel_seconds], required)):
            raise ValueError("系列作品不能单独改变轨迹、人物比例或动画周期；全部使用同一个规格版本")
    # 确保整张人物画布（包括透明边距）能在垂直方向容纳。
    bg_ratio = images[0].width / images[0].height
    height_fraction = args.rider_width * bg_ratio * images[1].height / images[1].width
    if args.track_y - args.ground_y * height_fraction < 0 or args.track_y + (1-args.ground_y)*height_fraction > 1:
        raise ValueError("人物画布会超出背景上下边缘，请减小 rider-width 或调整 track-y")
    config = {
        "title": args.title, "backgroundSize": list(images[0].size),
        "frameSize": list(images[1].size), "trackY": args.track_y,
        "groundY": args.ground_y, "riderWidth": args.rider_width,
        "cycleMs": args.cycle_ms, "travelSeconds": args.travel_seconds,
        "characterReference": str(args.character_reference.resolve()) if args.character_reference else None,
        "provenance": args.provenance,
        "layoutProfile": profile["id"] if not args.allow_legacy_layout else "legacy-unstandardized",
        "layoutProfileHash": profile_hash if not args.allow_legacy_layout else None,
        "nativeRiderDisplaySize": profile["riderDisplaySize"] if not args.allow_legacy_layout else None,
        "phaseDegrees": profile["phaseDegrees"] if not args.allow_legacy_layout else None,
    }
    template_path = Path(__file__).resolve().parent.parent / "assets" / "scene-template.html"
    template = template_path.read_text(encoding="utf-8")
    output.mkdir(parents=True, exist_ok=True)
    names = ["background.png", "rider-01.png", "rider-02.png", "rider-03.png"]
    uris = []
    for im, name in zip(images, names):
        path = output / name
        im.save(path, "PNG")
        uris.append("data:image/png;base64," + base64.b64encode(path.read_bytes()).decode("ascii"))
    payload = json.dumps({**config, "images": uris}, ensure_ascii=False).replace("<", "\\u003c")
    page = template.replace("__PAGE_TITLE__", html.escape(args.title)).replace("__SCENE_DATA__", payload)
    (output / "index.html").write_text(page, encoding="utf-8")
    (output / "scene.json").write_text(json.dumps({**config, "files": names, "checks": reports},
                                                  ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    if geometry is not None:
        (output / "layout.json").write_text(json.dumps(geometry, ensure_ascii=False, indent=2)+"\n", encoding="utf-8")
    print(json.dumps({"output": str(output), "images": names, "checks": reports}, ensure_ascii=False, indent=2))


def main():
    profile, _ = load_profile()
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--background", type=Path, required=True)
    parser.add_argument("--frames", type=Path, nargs=3, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--title", default="冒险上下六千年")
    parser.add_argument("--geometry", type=Path, help="standardize_assets.py输出的layout.json")
    parser.add_argument("--allow-legacy-layout", action="store_true", help="仅在明确维护旧作品时使用；结果不属于标准系列")
    parser.add_argument("--track-y", type=float, default=profile["trackY"]/profile["backgroundSize"][1])
    parser.add_argument("--ground-y", type=float, default=profile["riderGroundY"]/profile["frameSize"][1])
    parser.add_argument("--rider-width", type=float, default=profile["riderDisplaySize"][0]/profile["backgroundSize"][0])
    parser.add_argument("--cycle-ms", type=float, default=profile["cycleMs"])
    parser.add_argument("--travel-seconds", type=float, default=profile["travelSeconds"])
    parser.add_argument("--character-reference", type=Path)
    parser.add_argument("--provenance", required=True, help="说明新生成、复用或拆分来源")
    args = parser.parse_args()
    try:
        build(args)
    except (ValueError, OSError, KeyError, TypeError, IndexError) as exc:
        parser.exit(1, f"无法组装：{exc}\n")


if __name__ == "__main__":
    main()
