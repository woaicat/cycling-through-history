#!/usr/bin/env python3
"""按实际轮毂量测等比缩放和定位四张素材；不重绘，不拉伸。依赖 Pillow。"""
import argparse
import json
import math
from pathlib import Path

from PIL import Image

from scene_contract import load_profile, pixel_hash, validate_package


def load_image(path):
    with Image.open(path) as source:
        if source.format != "PNG":
            raise ValueError(f"需要PNG：{path}")
        return source.convert("RGBA")


def standardize(background, frames, measurements, profile, profile_hash):
    if len(measurements["frames"]) != 3:
        raise ValueError("source-layout.json必须有三组实际轮毂量测")
    background_alpha = background.getchannel("A")
    if background_alpha.getextrema() != (255, 255):
        raise ValueError("背景必须完全不透明")
    width, height = profile["backgroundSize"]
    ground = measurements["backgroundGroundY"]
    if not math.isfinite(ground) or not 0 < ground < background.height:
        raise ValueError("backgroundGroundY必须是原背景中的实际骑行落地线像素坐标")
    # 完整覆盖目标画布，且原骑行线对齐到共同地平位置；不会压扁或补空白边。
    bg_scale = max(width/background.width, profile["trackY"]/ground,
                (height-profile["trackY"])/(background.height-ground))
    crop_fraction = 1-width*height/(background.width*background.height*bg_scale**2)
    if crop_fraction > profile["maxBackgroundCropFraction"]:
        raise ValueError("背景对齐固定路线需要裁掉超过20%的画面，请按共同构图重新生成")
    offset_x = (background.width*bg_scale-width)/2
    offset_y = ground*bg_scale-profile["trackY"]
    normalized_bg = background.transform((width, height), Image.Transform.AFFINE,
        (1/bg_scale, 0, offset_x/bg_scale, 0, 1/bg_scale, offset_y/bg_scale),
        Image.Resampling.BICUBIC)
    normalized, records = [], []
    for image, measure in zip(frames, measurements["frames"]):
        rear, front = measure["rearHub"], measure["frontHub"]
        values = [*rear, *front, measure["rearRadius"], measure["frontRadius"]]
        if len(rear) != 2 or len(front) != 2 or not all(math.isfinite(v) for v in values):
            raise ValueError("轮毂坐标和半径必须为有限数字")
        if not (0 <= rear[0] < front[0] < image.width and
                0 < rear[1] < image.height and 0 < front[1] < image.height and
                0 < measure["rearRadius"] and 0 < measure["frontRadius"]):
            raise ValueError("实际量测必须在图内，后轮在左、前轮在右，半径为正")
        scale = (profile["frontHub"][0]-profile["rearHub"][0])/(front[0]-rear[0])
        tx = profile["rearHub"][0]-rear[0]*scale
        ty = profile["rearHub"][1]-(rear[1]+front[1])*scale/2
        target = image.transform(tuple(profile["frameSize"]), Image.Transform.AFFINE,
            (1/scale, 0, -tx/scale, 0, 1/scale, -ty/scale), Image.Resampling.BICUBIC,
            fillcolor=(0, 0, 0, 0))
        # 主体变换后不得被新画布裁掉，即使裁切后看起来满足尺寸，也应报错。
        source_bounds = image.getchannel("A").point(
            lambda v: 255 if v > profile["alphaThreshold"] else 0).getbbox()
        if not source_bounds:
            raise ValueError("人物帧为空")
        projected = [source_bounds[0]*scale+tx, source_bounds[1]*scale+ty,
                     source_bounds[2]*scale+tx, source_bounds[3]*scale+ty]
        if projected[0] < 0 or projected[1] < 0 or projected[2] > target.width or projected[3] > target.height:
            raise ValueError("统一轮距后主体会被裁切，应按共同构图重新生图")
        record = {
            "rearHub": [rear[0]*scale+tx, rear[1]*scale+ty],
            "frontHub": [front[0]*scale+tx, front[1]*scale+ty],
            "rearRadius": measure["rearRadius"]*scale,
            "frontRadius": measure["frontRadius"]*scale,
            "rgbaSha256": pixel_hash(target),
            "sourceMeasurements": measure,
            "transform": {"scale": scale, "translate": [tx, ty]},
        }
        normalized.append(target)
        records.append(record)
    geometry = {"profileId": profile["id"], "profileHash": profile_hash,
        "backgroundRgbaSha256": pixel_hash(normalized_bg), "frames": records,
        "sourceBackgroundGroundY": ground,
        "backgroundTransform": {"scale": bg_scale, "cropOffset": [offset_x, offset_y],
                "cropFraction": crop_fraction},
        "measurementMethod": "用户或执行者量测源图轮毂与轮径；非自动语义识别"}
    result = [normalized_bg, *normalized]
    validate_package(result, geometry, profile, profile_hash)
    return result, geometry


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--background", type=Path, required=True)
    parser.add_argument("--frames", type=Path, nargs=3, required=True)
    parser.add_argument("--measurements", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    try:
        if args.output.exists() and (not args.output.is_dir() or any(args.output.iterdir())):
            raise ValueError("输出目录须为新的或空目录")
        profile, profile_hash = load_profile()
        measurements = json.loads(args.measurements.read_text(encoding="utf-8"))
        result, geometry = standardize(load_image(args.background),
            [load_image(path) for path in args.frames], measurements, profile, profile_hash)
        args.output.mkdir(parents=True, exist_ok=True)
        for name, image in zip(["background.png", "rider-01.png", "rider-02.png", "rider-03.png"], result):
            image.save(args.output/name, "PNG")
        (args.output/"layout.json").write_text(json.dumps(geometry, ensure_ascii=False, indent=2)+"\n", encoding="utf-8")
        print(f"已输出{profile['id']}标准素材：{args.output.resolve()}")
    except (ValueError, OSError, KeyError, TypeError, IndexError) as exc:
        parser.exit(1, f"无法标准化：{exc}\n")


if __name__ == "__main__":
    main()
