"""跨风格骑行场景的共用尺寸与几何校验。"""
import hashlib
import json
import math
from pathlib import Path


PROFILE_PATH = Path(__file__).resolve().parent.parent / "assets" / "scene-profile.json"


def load_profile():
    profile = json.loads(PROFILE_PATH.read_text(encoding="utf-8"))
    digest = hashlib.sha256(PROFILE_PATH.read_bytes()).hexdigest()
    return profile, digest


def pixel_hash(image):
    return hashlib.sha256(image.convert("RGBA").tobytes()).hexdigest()


def significant_bounds(image, profile):
    alpha = image.convert("RGBA").getchannel("A")
    threshold = profile["alphaThreshold"]
    return alpha.point(lambda value: 255 if value > threshold else 0).getbbox()


def validate_frames(images, records, profile):
    if len(images) != 3 or len(records) != 3:
        raise ValueError("必须有三张帧和三组实际量测记录")
    tops, grounds = [], []
    for index, (image, record) in enumerate(zip(images, records), 1):
        if list(image.size) != profile["frameSize"]:
            raise ValueError(f"第{index}帧必须为{profile['frameSize']}，不可只改网页宽度")
        if record["rgbaSha256"] != pixel_hash(image):
            raise ValueError(f"第{index}帧已改变，与量测记录不符，请重新标准化")
        for key, target in [("rearHub", profile["rearHub"]), ("frontHub", profile["frontHub"])]:
            actual = record[key]
            if len(actual) != 2 or any(not math.isfinite(v) for v in actual):
                raise ValueError("轮毂坐标必须为两个有限数字")
            if math.dist(actual, target) > profile["anchorTolerance"]:
                raise ValueError(f"第{index}帧{key}不在共同基准位置")
        for key in ["rearRadius", "frontRadius"]:
            radius = record[key]
            if not math.isfinite(radius) or abs(radius-profile["wheelRadius"]) > profile["radiusTolerance"]:
                raise ValueError(f"第{index}帧轮径不符合共同基准；应重新生图，不能非等比拉伸")
        ground = max(record["rearHub"][1]+record["rearRadius"],
                     record["frontHub"][1]+record["frontRadius"])
        if abs(ground-profile["riderGroundY"]) > profile["groundTolerance"]:
            raise ValueError(f"第{index}帧轮胎接地点不符合共同基准")
        bounds = significant_bounds(image, profile)
        if not bounds:
            raise ValueError(f"第{index}帧为空")
        if bounds[0] < profile["subjectHorizontalBounds"][0] or bounds[2] > profile["subjectHorizontalBounds"][1]:
            raise ValueError(f"第{index}帧主体过宽，超出共同安全区")
        if abs(bounds[1]-profile["headTop"]) > profile["headTopTolerance"]:
            raise ValueError(f"第{index}帧人物整体高度不符合共同基准；重新按构图导图生成")
        if bounds[3] > profile["riderGroundY"]+profile["groundTolerance"]+1:
            raise ValueError(f"第{index}帧主体或脚底超出轮胎落地线")
        tops.append(bounds[1])
        grounds.append(ground)
    if max(tops)-min(tops) > profile["headTopFrameSpread"]:
        raise ValueError("三帧头顶高度跳动超过允许值")
    if max(grounds)-min(grounds) > profile["groundFrameSpread"]:
        raise ValueError("三帧落地高度跳动超过允许值")


def validate_package(images, geometry, profile, profile_hash):
    if list(images[0].size) != profile["backgroundSize"]:
        raise ValueError(f"背景必须为{profile['backgroundSize']}，请先标准化素材")
    if geometry["profileId"] != profile["id"] or geometry["profileHash"] != profile_hash:
        raise ValueError("素材规格版本不同，不能混入同一系列")
    if geometry["backgroundRgbaSha256"] != pixel_hash(images[0]):
        raise ValueError("背景与标准化记录不符，请重新标准化")
    validate_frames(images[1:], geometry["frames"], profile)
